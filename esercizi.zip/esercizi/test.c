#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {



    return 0;
}